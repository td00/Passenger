#!/usr/bin/bash
if [ "$EUID" -ne 0 ]
	then echo "Please run under root privileges."
else
    sudo cp -r ./Passenger /usr/share/
    sudo cp ./Passenger.desktop /usr/share/applications/
    sudo echo "#/usr/bin/bash
    /usr/share/Passenger/Passenger" > /usr/bin/passenger
    sudo chmod +x /usr/bin/passenger
    if [[ -f /usr/share/Passenger/Passenger && -f /usr/share/applications/Passenger.desktop && -f /usr/bin/passenger ]]; then
        echo "Installation has been completed."
    else
        echo "Installation is not successfull. Try again."
    fi
fi